ds2_pgsql_load_cust_readme.txt

Instructions for loading DVD Store Version 2 (DS2) database customer data
(assumes data files are in directory ../../../data_files/cust)

  pgsql -d ds2 < pgsqlds2_load_cust.sql

<dave_jaffe@dell.com> and <todd_muirhead@dell.com>  5/13/05
